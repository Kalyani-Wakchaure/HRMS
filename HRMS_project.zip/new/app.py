from flask import Flask, render_template, request, redirect, url_for, flash, session
import MySQLdb

app = Flask(__name__)
app.secret_key = '49494asdklfjasdklflaksd'

# MySQL configurations
db = MySQLdb.connect(host="localhost", user="root", passwd="Cdac@2022", db="new_data")

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form['role']
        email = request.form['email']
        password = request.form['password']

        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE email=%s AND password=%s AND role=%s", (email, password, role))
        user = cursor.fetchone()

        if user:
            return redirect(url_for('home')) #dashboard
        else:
            flash('Login Failed. Check your role, email, and password.')
            return redirect(url_for('login')) #home
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        role = request.form['role']

        if password != confirm_password:
            flash('Passwords do not match!')
            return redirect(url_for('register'))

        cursor = db.cursor()
        cursor.execute("INSERT INTO users (name, email, password, role) VALUES (%s, %s, %s, %s)", (name, email, password, role))
        db.commit()
        flash('Registration successful! Please log in.')
        return redirect(url_for('login')) #home
    
    return render_template('register.html')

@app.route('/job_desk')
def job_desk():
    return render_template('job_desk.html')

@app.route('/Employee')
def Employee():
    return render_template('employee.html')

@app.route('/Leave')
def Leave():
    return render_template('leave.html')

@app.route('/employee', methods=['GET', 'POST'])
def employee():
    if request.method == 'POST':
        profile = request.form['profile']
        employee_id = request.form['employee_id']
        designation = request.form['designation']
        employment_status = request.form['employment_status']
        department = request.form['department']
        workshift = request.form['workshift']
        joining_date = request.form['joining_date']
        salary = request.form['salary']
        role = request.form['role']

        cursor = db.cursor()
        cursor.execute("INSERT INTO employees (profile, employee_id, designation, employment_status, department, workshift, joining_date, salary, role) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)", 
                       (profile, employee_id, designation, employment_status, department, workshift, joining_date, salary, role))
        db.commit()
        flash('Employee added successfully!')
        return redirect(url_for('view_employees'))
    
    return render_template('employee.html')

@app.route('/view_employees')
def view_employees():
    cursor = db.cursor()
    cursor.execute("SELECT * FROM employees")
    employees = cursor.fetchall()
    return render_template('view_employees.html', employees=employees)



@app.route('/dashboard')
def dashboard():
    return "Welcome to the Admin Dashboard!"
    '''if 'logged_in' in session and session['role'] == 'App Admin':
        return render_template('dashboard.html')
    return redirect(url_for('login'))'''
if __name__ == '__main__':
    app.run(debug=True)



'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Desk</title>
</head>
<body>
    <h1>Employee Desk</h1>
    <p>This is the employee page page.</p>
</body>
</html>
'''